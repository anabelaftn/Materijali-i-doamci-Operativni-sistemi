#ifndef BANKA_H_INCLUDED
#define BANKA_H_INCLUDED

#include "klijent.h"

class Banka
{
private:
    Klijent &klijent;
    /* Dopuniti po potrebi... */

public:
    Banka(Klijent &k) : klijent(k)
    {
	/* Dopuniti po potrebi... */
    }

    /*
     * rbr - Redni broj klijenta
     * tip - Tip klijenta (fizicko ili pravno lice)
     *
     * Obavezno pozvati sledece metode:
     * klijent.ceka         - Kada je klijent izabrao red i poceo da ceka.
     * klijent.dosao_na_red - Kada klijent dodje do saltera i vrsi transakciju.
     * klijent.izlazi       - Na kraju transakcije, kada se salter oslobadja.
     */
    void klijent_vrsi_transakciju(int rbr, TipKlijenta tip)
    {
	/* Implementirati... */
    }
};

#endif // BANKA_H_INCLUDED
