#ifndef KLIJENT_H_INCLUDED
#define KLIJENT_H_INCLUDED

#include <mutex> 

using namespace std;

enum TipKlijenta { FIZICKO_LICE = 0, PRAVNO_LICE };

class Klijent
{
protected:
    mutex term_mx;

public:
    /*
     * rbr    - Redni broj klijenta
     * tip    - Tip klijenta (fizicko ili pravno lice)
     * salter - Broj saltera na koji ceka klijent
     */
    virtual void ceka(int rbr, TipKlijenta tip, int salter)
    {
        unique_lock <mutex> l(term_mx);
        cout << "Klijent " << rbr << ", koji je "
	     << (tip == FIZICKO_LICE ? "FIZICKO" : "PRAVNO") << " lice, "
	     << "ceka u redu za salter broj " << salter << "." << endl;
    }
    
    /*
     * rbr    - Redni broj klijenta
     * tip    - Tip klijenta (fizicko ili pravno lice)
     * salter - Broj saltera kojeg je zauzeo klijent
     */
    virtual void dosao_na_red(int rbr, TipKlijenta tip, int salter)
    {
        unique_lock <mutex> l(term_mx);
        cout << "Klijent " << rbr << ", koji je "
	     << (tip == FIZICKO_LICE ? "FIZICKO" : "PRAVNO") << " lice, "
	     << "je dosao na red na salter " << salter << "." << endl;
    }

    /*
     * rbr    - Redni broj klijenta
     * tip    - Tip klijenta (fizicko ili pravno lice)
     * salter - Broj saltera kojeg je oslobodio klijent
     */
    virtual void izlazi(int rbr, TipKlijenta tip, int salter)
    {
        unique_lock <mutex> l(term_mx);
        cout << "Klijent " << rbr << ", koji je "
	     << (tip == FIZICKO_LICE ? "FIZICKO" : "PRAVNO") << " lice, "
	     << "napusta salter " << salter << " i izlazi iz banke." << endl;
    }
};

#endif // KLIJENT_H_INCLUDED
