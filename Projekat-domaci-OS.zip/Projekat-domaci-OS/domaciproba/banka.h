#ifndef BANKA_H_INCLUDED
#define BANKA_H_INCLUDED

#include <condition_variable>
#include <mutex>
#include <stdlib.h>
#include "klijent.h"

using namespace chrono;

class Banka
{
private:
    Klijent &klijent;
    mutex m;
    condition_variable cv_redovi[4];
    bool free_salter[4];
    int clients_in_line[4];

    /* Dopuniti po potrebi... */

public:
    Banka(Klijent &k) : klijent(k)
    {
        for(int i=0; i<4; i++)
            {
                clients_in_line[i]=0;
                free_salter[i]=true;
            }
    }

    /*
     * rbr - Redni broj klijenta
     * tip - Tip klijenta (fizicko ili pravno lice)
     *
     * Obavezno pozvati sledece metode:
     * klijent.ceka         - Kada je klijent izabrao red i poceo da ceka.
     * klijent.dosao_na_red - Kada klijent dodje do saltera i vrsi transakciju.
     * klijent.izlazi       - Na kraju transakcije, kada se salter oslobadja.
     */
    void klijent_vrsi_transakciju(int rbr, TipKlijenta tip)
    {
        unique_lock<mutex> l(m);
        int idx;
        if(tip == PRAVNO_LICE)
        {
            if (clients_in_line[2] + !free_salter[2] <= clients_in_line[3] + !free_salter[3])
            {
                idx = 2;
            }
            else
            {
                idx = 3;
            }

            while (!free_salter[idx])
            {
                clients_in_line[idx]++;
                klijent.ceka(rbr,tip,idx+1);
                cv_redovi[idx].wait(l);
                clients_in_line[idx]--;
            }
            free_salter[idx] = false;
            klijent.dosao_na_red(rbr,tip,idx+1);
            l.unlock();
            this_thread::sleep_for(milliseconds(rand()%2001 + 1000));
            l.lock();
            free_salter[idx] = true;
            klijent.izlazi(rbr,tip,idx+1);
            cv_redovi[idx].notify_one();
        }
        else if (tip == FIZICKO_LICE)
        {
            if (clients_in_line[0] + !free_salter[0] <= clients_in_line[1] + !free_salter[1])
            {
                idx = 0;
            }
            else
            {
                idx = 1;
            }


            while (!free_salter[idx])
            {
                clients_in_line[idx]++;
                klijent.ceka(rbr,tip,idx+1);
                cv_redovi[idx].wait(l);
                clients_in_line[idx]--;
            }
            free_salter[idx] = false;
            klijent.dosao_na_red(rbr,tip,idx+1);
            l.unlock();
            this_thread::sleep_for(milliseconds(rand()%2001 + 1000));
            l.lock();
            free_salter[idx] = true;
            klijent.izlazi(rbr,tip,idx+1);
            cv_redovi[idx].notify_one();
        }
    }
};

#endif // BANKA_H_INCLUDED
