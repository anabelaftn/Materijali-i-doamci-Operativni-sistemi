
/*
 * Napisati konkurentni program koji modeluje rad saltera u banci. Banka ima
 * cetiri saltera na koje dolaze klijenti. Salteri su rasporedjeni tako da su
 * dva saltera za fizicka lica, a preostala dva za pravna lica.
 *
 * Klijenti mogu biti fizicka ili pravna lica. Kada klijent udje u banku, on
 * mora da izabere jedan od dva odgovarajuca saltera. Salteri za fizicka lica su
 * numerisani brojevima 1 i 2, dok su salteri za pravna lica numerisani 3 i 4.
 * Svaki salter ima svoj zaseban red.
 *
 * Klijenti uvek biraju kraci red, odnosno, onaj red u kojem manji broj
 * klijenata ceka. Treba obratiti paznju da fizicka lica ne mogu stati u red za
 * pravna lica, niti suprotno.
 *
 * Transakcije traju nasumican vremenski period izmedju 1000 i 3000 milisekundi.
 *
 * Data je klasa Banka u kojoj treba implementirati metodu
 * "klijent_vrsi_transakciju".

 */
#include <thread>
#include <iostream>
#include "banka.h"
#include "klijent.h"

using namespace std;

/*
 * b   - Objekat klase Banka
 * rbr - Redni broj klijenta
 * tip - Tip klijenta (fizicko ili pravno lice)
 */
void klijent(Banka &b, int rbr, TipKlijenta tip)
{
    b.klijent_vrsi_transakciju(rbr, tip);
}

void testirajSve()
{
    const int BROJ_KLIJENATA = 30;

    Klijent k;
    Banka b(k);

    thread klijenti[BROJ_KLIJENATA];

    for(int i = 0; i < BROJ_KLIJENATA; i++){
        klijenti[i] = thread(klijent, ref(b), i+1, (TipKlijenta)(i%2));
    }

    for(int i = 0; i < BROJ_KLIJENATA; i++){
        klijenti[i].join();
    }

}

int main()
{
    testirajSve();
    return 0;
}

