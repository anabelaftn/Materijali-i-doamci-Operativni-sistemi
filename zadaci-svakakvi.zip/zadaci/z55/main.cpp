#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

bool poredi(int a, int b){
    return a>b;
    }
int main()
{
    vector<int> brojevi;

    cout<<"Uneiste 5 celih brojeva: "<<endl;
    int broj;
    for(int i=0; i<5;i++){
        cin>> broj;
        brojevi.push_back(broj);
    }
    sort(brojevi.begin(), brojevi.end(), poredi);

    cout<< "Sotritarani niz"<<endl;

    vector<int>:: const_iterator it;

    for(it= brojevi.begin(); it!= brojevi.end(); ++it){
        cout<< *it<<endl;

    }

    return 0;
}
