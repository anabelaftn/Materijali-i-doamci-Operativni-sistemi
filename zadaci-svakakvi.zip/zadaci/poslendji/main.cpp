#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

vector<int> min_n(const vector<int>& a, const vector<int>& b){
        vector<int>::iterator it;
        vector<int>::iterator pit;


        vector<int> novi;
        vector<int> pomA;
        vector<int> pomB;
        vector<int> kraj;
        pomA = a;
        pomB = b;
int x, y;
        for()
        for(it = pomA.begin(); it!= pomA.end(); it++){
            x= *it;
            for(pit = pomA.begin(); pit!= pomA.end(); pit++){

                    y= *pit;



            }
       }

      sort(pom.begin(), pom.end());



       for(it = pom.begin(); it!= pom.begin()+n; it++){

            kraj.push_back(*it);
       }
    return kraj;
}

int main()
{
    vector<int> A;
    vector<int> B;
    vector<int> brojevi_nazad;

     cout<<"Uneiste 1. vektor "<<endl;
    int broj;
    for(int i=0; i<4;i++){
        cin>> broj;
        A.push_back(broj);
    }
     cout<<"Uneiste 2. vektor "<<endl;
    for(int i=0; i<4;i++){
        cin>> broj;
        B.push_back(broj);
    }




   /*brojevi_nazad= min_n(brojevi, 3);
    vector<int>::iterator it;
    for(it = brojevi_nazad.begin(); it!= brojevi_nazad.end(); it++){
        cout<< *it<<endl;
    }

*/



    return 0;
}
