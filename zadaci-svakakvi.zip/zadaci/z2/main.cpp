#include <iostream>
#include <map>

using namespace std;

int main()
{
    map<string, string> recnik;
    recnik["red"]="crvena";
    recnik["blue"] = "plava";
    recnik["green"] = "zelena";
    recnik.insert(std::pair<string,string> ("black","crna"));

    string rec;
    cout<<"Unesite rec->\t";
    while(getline(cin,rec)){
            if(recnik.find(rec)!=recnik.end()){
        cout<<"Prevod za rec "<< rec << " je "<< recnik[rec]<<endl;


    }
    cout<<"Velicina mape je "<< recnik.size()<<endl;
    }




    return 0;
}
