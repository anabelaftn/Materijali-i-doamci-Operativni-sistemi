/*
Napisati program koji omogućava evidentiranje fakultetskih učionica.

Za svaku učionicu potrebno je evidentirati naziv učionice, kvadraturu i sve računare koji se nalaze u učionici.
Za svaki računar evidentiraju se podaci o hard disku i procesoru.

U okviru main funkcije, definisati jednu učionicu koja sadrži dva računara.
Zatim je potrebno na konzolu ispisati hard disk i procesor svakog računara u učionici.
*/

#include <iostream>
#include <list>


using namespace std;

class Racunar {
private:
    string processor;
    string disk;
public:
    Racunar() {}
    Racunar(string p, string d) {
        processor = p;
        disk = d;
    }
    string getProcessor() const { return processor; }
    string getDisk() const {return disk;}
};

class Ucionica {
private:
        string naziv;
        double kvadratura;
        list<Racunar> racunari;
        /*Racunar racunari[10];
        int brRac; */
public:
    Ucionica(string n, double kv) {
        naziv = n;
        kvadratura = kv;
        //brRac = 0;
    }
    string getNaziv() const {return naziv;}
    double getKvadratura() const {return kvadratura;}
    /*int size() const {return brRac;}

    void dodajRacunar(Racunar r) {
    racunari[brrac] = r;
    brRac++;
    }
    Racunar getRacunar(int i) {
    return racunari[i];
    } */
    void dodajRacunar (Racunar r) {
        racunari.push_back(r);
    }
    list<Racunar> getRacunari() {
        return racunari;
    }
};

int main()
{
    Racunar r1("Intel", "WD"), r2("AMD", "Samsung");
    Ucionica u("NTP 317", 33.65);

    u.dodajRacunar(r1);
    u.dodajRacunar(r2);

    cout << "Ucionica" << u.getNaziv() << " ( " <<  u.getKvadratura() << " ): " << endl;
    /*for (int i = 0; i < u.size(); i++){
        Racunar r = u.dodajRacunar(i);
        cout << "\tProcesor:" << r.getProcessor() << endl;
        cout << "Disk: " << r.getDisk() << endl;
    }   */

    list<Racunar> racunari = u.getRacunari();
    list<Racunar>::iterator it;
    for (it = racunari.begin(); it != racunari.end(); ++it) {
        cout << "Processor:" << (*it).getProcessor() << endl;
        cout << "Disk:" << it->getDisk() << endl;
    }

    return 0;
}
