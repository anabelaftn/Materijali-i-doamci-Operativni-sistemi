/*
Napraviti funkciju:

vector<int> min_n(const vector<int>& v,	int n);

Ova funkcija vraća vektor koji sadrži n najmanjih elemenata iz vektora v.
Podrazumeva se: v.size()>=n
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<int> min_n(const vector<int>& v,	int n) {

    vector<int> v_copy = v;

    sort(v_copy.begin(), v_copy.end());

    v_copy.resize(n);

    return v_copy;
}

int main()
{
    vector<int> v = {16, 25, 11, 20, 7};

    vector<int> res = min_n(v, 3);

    vector<int>::const_iterator it;
    for(it = res.begin(); it != res.end(); ++it) {
        cout << *it << endl;
    }
    return 0;
}
