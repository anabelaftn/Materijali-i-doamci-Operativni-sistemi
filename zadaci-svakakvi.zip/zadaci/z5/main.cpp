#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main()
{
    vector<int> v;
    int broj;
    cout<<"unesite 5 celih brojeva"<<endl;

    for(int i = 0; i<5; i++){
        cin>>broj;
        v.push_back(broj);
    }
    //int maksimalni_broj = *max_element(v.begin(), v.end());
    //cout<<"Maksimalni broj je "<< maksimalni_broj<< endl;
    sort(v.begin(), v.end());
    reverse(v.begin(), v.end());
    cout<<"----"<<endl;
    for(auto it = v.begin(); it != v.end(); ++it ){
        cout<< *it<<endl;
    }

    return 0;
}
