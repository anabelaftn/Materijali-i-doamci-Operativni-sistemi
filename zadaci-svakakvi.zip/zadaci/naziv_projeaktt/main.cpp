#include <iostream>
#include <string>
#include <list>
using namespace std;

class Racunar{
private:
    string disk;
    string procesor;
public:
    string getDisk(){
        return disk;
    }
    string getProcesor(){
        return procesor;
    }
    void setDisk(string d){
        disk= d;
    }
    void setProcesor(string p){
        procesor = p;
    }
};


class Ucionica{
private:
    string naziv;
    double kvadratura;
   /// Racunar racunari[30];
   list<Racunar> racunari;
public:
    string getNaziv(){
        return naziv;
    }

    double getKvadratura(){
        return kvadratura;
    }
 /*   Racunar getRacunar(int i){
        return racunari[i];
    }*/

    void setNaziv(string n){
        naziv= n;
    }
    void setKvadratura(double kv){
        kvadratura= kv;
    }

   /* void dodajRacunar(Racunar r, int i){
        racunari[i] = r;
    }*/
    list<Racunar> getRacunari(){
        return racunari;
    }
    void dodajRacunar(Racunar r){
        racunari.push_back(r); ///Doda na kraj liste
    }

};

int main()
{
    Ucionica u;
    u.setNaziv("NTP- 317");
    u.setKvadratura(334);
    Racunar r1, r2;
    r1.setDisk("disk1");
    r1.setProcesor("procesor1");
    r2.setDisk("disk2");
    r2.setProcesor("procesor2");

   /* u.dodajRacunar(r1,0);
    u.dodajRacunar(r2,1);

   for(int i=0; i<2;i++){
        cout<<"DISK: "<<u.getRacunar(i).getDisk()<<endl;
        cout<<"PROCESOR: "<<u.getRacunar(i).getProcesor()<<endl;

    }*/
    u.dodajRacunar(r1);
    u.dodajRacunar(r2);

     list<Racunar>::iterator it;
    list<Racunar> racunari = u.getRacunari();

    for(it = racunari.begin(); it!= racunari.end(); it++){
        cout<<"Procesor: "<< it -> getProcesor()<<endl;
        cout<<"Disk: "<< it -> getDisk()<<endl;


    }

        return 0;
}
