#include <iostream>
#include <vector>
#include <list>

using namespace std;

class Racunar {
private:
    string cpu;
    string hdd;

public:
    Racunar() {}

    Racunar(string _cpu, string _hdd){
        cpu = _cpu;
        hdd = _hdd;
    }

    string getCpu(){
        return cpu;
    }
    string getHdd(){
        return hdd;
    }



};

class Ucionica{
private:
        string naziv;
        double kvadratura;
        list<Racunar> racunari;

public:
    Ucionica(){}

    Ucionica(string _naziv, double _kvadratura){
        naziv= _naziv;
        kvadratura = _kvadratura;
    }
    void addRacunar(Racunar r){
        racunari.push_back(r);
    }
    list<Racunar> getRacunar(){
        return racunari;
    }


};

int main()
{
    Racunar r1("cpu1", "hdd1");
    Racunar r2("cpu2", "hdd2");

    Ucionica u("ntp 317", 30.5);
    u.addRacunar(r1);
    u.addRacunar(r2);


    list<Racunar> racunari = u.getRacunar();
    list<Racunar>:: iterator it;
    int i=0;
    for (it = racunari.begin(); it!=racunari.end(); ++it, ++i){
        cout<<"Procesor racunara " << i << " je " << it->getCpu()<<endl;
        cout<<"HDD racunara " << i << " je " << it->getHdd()<<endl;
    }

    /*for(int i =  0; i<2; i++){
        cout<<"Procesor racunara " << i << " je: " << u.getRacunar(i).getCpu()<<endl;
        cout<<"HDD racunara " << i << " je: " << u.getRacunar(i).getHdd()<<endl;
    }*/



    return 0;
}



