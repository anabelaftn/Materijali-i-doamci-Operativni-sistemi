#include <iostream>
#include <algorithm>
#include <vector>

using namespace std;

int main()
{
    vector<int> v;
    int broj;
    cout<<"unesite 5 celih brojeva"<<endl;

    for(int i = 0; i<5; i++){
        cin>>broj;
        v.push_back(broj);
    }
    int maksimalni_broj = *max_element(v.begin(), v.end());
    cout<<"Maksimalni broj je "<< maksimalni_broj<< endl;

    return 0;
}
