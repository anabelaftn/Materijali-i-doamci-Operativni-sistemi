#include <iostream>
#include <string>
#include <map>
using namespace std;

int main()
{

    map<string, string> recnik;
    recnik["black"] = "crna";
    recnik["red"] = "crvena";
    recnik["white"] = "bela";

    string rec;

    while(getline(cin,rec)){
        cout<< "Prevod: "<< recnik[rec]<< endl;
    }

    return 0;
}
