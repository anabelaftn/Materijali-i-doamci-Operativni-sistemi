/*
Korisnik treba da unese 5 celih brojeva koristeći tastaturu (standardni ulaz).
Korišćenjem STL algoritma, među tih 5 brojeva potrebno je pronaći najveći.
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main()
{
    vector<int> brojevi;
    int pom;
    for(int i = 0; i<5; i++) {
        cin >> pom;
        brojevi.push_back(pom);
    }

    int najveci = *max_element(brojevi.begin(), brojevi.end());

    cout << "najveci broj je "<< najveci << endl;
    return 0;
}
