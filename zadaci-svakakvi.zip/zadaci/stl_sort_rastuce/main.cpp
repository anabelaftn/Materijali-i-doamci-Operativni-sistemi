/*
Uneti 5 celih brojeva sa standardnog ulaza.
Korišćenjem STL algoritma sortirati brojeve u rastućem redosledu.
*/

#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main()
{
    vector<int> brojevi;
    int pom;
    for(int i = 0; i<5; i++) {
        cin >> pom;
        brojevi.push_back(pom);
    }

    sort(brojevi.begin(), brojevi.end());

    vector<int>::const_iterator it;
    for(it = brojevi.begin(); it != brojevi.end(); ++it) {
        cout << *it << endl;
    }
    return 0;
}
