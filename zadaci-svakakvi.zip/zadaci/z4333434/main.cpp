#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main()
{
    vector<int> brojevi;

    cout<<"Uneiste 5 celih brojeva: "<<endl;
    int broj;
    for(int i=0; i<5;i++){
        cin>> broj;
        brojevi.push_back(broj);
    }

    int maximalni = *max_element(brojevi.begin(), brojevi.end());
    cout<<"Najveci je: "<<maximalni<<endl;

    return 0;
}
