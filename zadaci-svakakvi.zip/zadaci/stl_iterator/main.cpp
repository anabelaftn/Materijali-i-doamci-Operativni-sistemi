/*
Napraviti program koji prihvata proizvoljan broj linija sa standardnog ulaza i zatim ih ispisuje u redosledu kojim su uneti.
*/

#include <iostream>
#include <list>
#include <string>

using namespace std;

int main()
{
    list<string> reci;
    string rec;

    while(getline(cin, rec)){
        reci.push_back(rec);
    }

    list<string>::const_reverse_iterator it;
    /*for(it = reci.rbegin(); it != reci.rend(); ++it) {
        cout << *it << endl;
    }*/

    for(it = (reci.end()-1); it != (reci.begin()-1); --it) {
        cout << *it << endl;
    }

    /*list<string>::const_iterator it;
    for(it = reci.begin(); it != reci.end(); ++it) {
        cout << (*it) << endl;
    }*/
    return 0;
}
