#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

vector<int> min_n(const vector<int>& v, int n){
        vector<int>::iterator it;

        vector<int> novi;
        vector<int> pom;
                vector<int> kraj;

        novi = v;
        for(it = novi.begin(); it!= novi.end(); it++){

            pom.push_back(*it);
       }

      sort(pom.begin(), pom.end());



       for(it = pom.begin(); it!= pom.begin()+n; it++){

            kraj.push_back(*it);
       }
    return kraj;
}

int main()
{
    vector<int> brojevi;
    vector<int> brojevi_nazad;

     cout<<"Uneiste 5 celih brojeva: "<<endl;
    int broj;
    for(int i=0; i<5;i++){
        cin>> broj;
        brojevi.push_back(broj);
    }

   brojevi_nazad= min_n(brojevi, 3);
    vector<int>::iterator it;
    for(it = brojevi_nazad.begin(); it!= brojevi_nazad.end(); it++){
        cout<< *it<<endl;
    }





    return 0;
}
