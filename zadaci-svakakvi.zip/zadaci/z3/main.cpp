#include <iostream>
#include <vector>
using namespace std;

int main()
{
    vector<string> reci;
    string rec;
    for(int i =0; i<4;i++){

        cin>>rec;
        reci.push_back(rec);
    }
    cout<<"ispis"<<endl;

    for(auto it=reci.rbegin(); it!=reci.rend();++it){
        cout<<" " <<*it;
        cout<<"\n";
    }


    return 0;
}
