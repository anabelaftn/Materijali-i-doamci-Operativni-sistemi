#include <iostream>
#include <vector>

using namespace std;

int main()
{
    string rec;
    vector<string> lista_reci;

    while(getline(cin,rec)){
        lista_reci.push_back(rec);
    }
     vector<string>::iterator it;
      vector<string>::reverse_iterator rit;
    vector<string> pom  = lista_reci;

    for(it = pom.begin(); it!= pom.end(); it++){
        cout<< *it<<endl;
    }
    cout<<endl<<"OBRNUTO"<<endl;

   /* for(it = pom.rend()-1; it!= pom.rbegin()-1; it--){
        cout<< *it<<endl;
    }
*/
    for(rit = pom.rbegin(); rit!= pom.rend(); rit++){
        cout<< *rit<<endl;
    }


    return 0;
}
