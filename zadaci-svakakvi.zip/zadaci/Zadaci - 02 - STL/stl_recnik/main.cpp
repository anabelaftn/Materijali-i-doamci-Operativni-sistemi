/*
Napraviti jednostavan program za prevođenje reči sa engleskog na srpski jezik.
Nakon unosa reči sa standardnog ulaza, ispisuje se prevod (ukoliko unesena reč postoji u rečniku).

Uneti 3 engleske reči i njihove prevode na srpski.
*/

#include <iostream>
#include <map>
#include <string>

using namespace std;

int main()
{
    // key, value -> string(eng), string(srb)
    map<string, string> recnik;
    recnik["blue"] = "plavo";
    recnik["red"] = "crveno";
    recnik["white"] = "belo";

    string rec;
    cout << " Recnik - unesite rec za prevod: " << endl;

    // sve dok se ne unese ctrl + D
    while(getline(cin, rec)){
        cout << rec << " - " << recnik[rec] << end;

    }

    return 0;
}
